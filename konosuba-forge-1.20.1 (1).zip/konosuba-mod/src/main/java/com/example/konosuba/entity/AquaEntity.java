package com.example.konosuba.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Goddess of water: heals nearby players, purifies undead, cries and runs when hurt. */
public class AquaEntity extends KonosubaCharacter {

    public AquaEntity(EntityType<? extends AquaEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes();
    }

    @Override
    protected String getCharacterId() {
        return "aqua";
    }

    @Override
    protected MobEffectInstance getBlessing() {
        return new MobEffectInstance(MobEffects.REGENERATION, 600, 1);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.5D));
    }

    @Override
    public boolean canBreatheUnderwater() {
        return true;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (this.tickCount % 40 != 0) return;
        ServerLevel sl = (ServerLevel) this.level();

        // Healing aura
        for (Player p : sl.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(8.0D))) {
            if (p.getHealth() < p.getMaxHealth()) {
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0, true, true));
                sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1.0D, p.getZ(),
                        4, 0.3D, 0.5D, 0.3D, 0.0D);
            }
        }
        // Turn Undead
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(6.0D),
                x -> x.getMobType() == MobType.UNDEAD && x.isAlive())) {
            e.hurt(this.damageSources().magic(), 4.0F);
            sl.sendParticles(ParticleTypes.SPLASH, e.getX(), e.getY() + 1.0D, e.getZ(),
                    10, 0.3D, 0.5D, 0.3D, 0.1D);
        }
    }
}
