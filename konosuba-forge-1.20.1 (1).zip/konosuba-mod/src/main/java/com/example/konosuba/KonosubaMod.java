package com.example.konosuba;

import com.example.konosuba.registry.ModCreativeTabs;
import com.example.konosuba.registry.ModEntities;
import com.example.konosuba.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(KonosubaMod.MODID)
public class KonosubaMod {
    public static final String MODID = "konosuba";

    public KonosubaMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModCreativeTabs.TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, KonosubaConfig.SPEC);
    }
}
