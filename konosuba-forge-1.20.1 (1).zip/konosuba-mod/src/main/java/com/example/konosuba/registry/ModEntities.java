package com.example.konosuba.registry;

import com.example.konosuba.KonosubaMod;
import com.example.konosuba.entity.AquaEntity;
import com.example.konosuba.entity.DarknessEntity;
import com.example.konosuba.entity.KazumaEntity;
import com.example.konosuba.entity.MeguminEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, KonosubaMod.MODID);

    public static final RegistryObject<EntityType<AquaEntity>> AQUA = ENTITIES.register("aqua",
            () -> EntityType.Builder.of(AquaEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("aqua"));

    public static final RegistryObject<EntityType<MeguminEntity>> MEGUMIN = ENTITIES.register("megumin",
            () -> EntityType.Builder.of(MeguminEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("megumin"));

    public static final RegistryObject<EntityType<KazumaEntity>> KAZUMA = ENTITIES.register("kazuma",
            () -> EntityType.Builder.of(KazumaEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.8F).clientTrackingRange(8).build("kazuma"));

    public static final RegistryObject<EntityType<DarknessEntity>> DARKNESS = ENTITIES.register("darkness",
            () -> EntityType.Builder.of(DarknessEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.9F).clientTrackingRange(8).build("darkness"));
}
