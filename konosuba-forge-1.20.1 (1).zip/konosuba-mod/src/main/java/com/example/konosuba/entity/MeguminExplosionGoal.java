package com.example.konosuba.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

public class MeguminExplosionGoal extends Goal {
    private static final int CHANT_TICKS = 50;
    private static final double MIN_DIST_SQ = 7.0D * 7.0D;
    private static final double MAX_DIST_SQ = 28.0D * 28.0D;

    private final MeguminEntity megumin;
    private int chant;

    public MeguminExplosionGoal(MeguminEntity megumin) {
        this.megumin = megumin;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = megumin.getTarget();
        if (t == null || !t.isAlive() || !megumin.canCast()) return false;
        double d = megumin.distanceToSqr(t);
        return d >= MIN_DIST_SQ && d <= MAX_DIST_SQ && megumin.getSensing().hasLineOfSight(t);
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity t = megumin.getTarget();
        return t != null && t.isAlive() && chant < CHANT_TICKS && megumin.canCast();
    }

    @Override
    public void start() {
        chant = 0;
        megumin.getNavigation().stop();
        megumin.announceChant();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity t = megumin.getTarget();
        if (t == null) return;
        megumin.getLookControl().setLookAt(t, 30.0F, 30.0F);
        chant++;

        if (megumin.level() instanceof ServerLevel sl) {
            // Magic circle telegraph on the target + sparkles around the caster
            sl.sendParticles(ParticleTypes.FLAME, t.getX(), t.getY() + 0.1D, t.getZ(), 4, 2.0D, 0.0D, 2.0D, 0.0D);
            sl.sendParticles(ParticleTypes.ENCHANT, megumin.getX(), megumin.getY() + 1.5D, megumin.getZ(),
                    3, 0.5D, 0.5D, 0.5D, 0.0D);
        }
        if (chant >= CHANT_TICKS) {
            megumin.castExplosion(t.position());
        }
    }

    @Override
    public void stop() {
        chant = 0;
    }
}
