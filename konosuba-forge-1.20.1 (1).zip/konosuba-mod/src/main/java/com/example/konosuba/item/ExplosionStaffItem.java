package com.example.konosuba.item;

import com.example.konosuba.KonosubaConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import javax.annotation.Nullable;

import java.util.List;

/** Hold right-click to chant, release to cast a huge explosion where you look. */
public class ExplosionStaffItem extends Item {
    public static final int CHANT_TICKS = 40;
    public static final double RANGE = 64.0D;

    public ExplosionStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) {
            player.displayClientMessage(Component.translatable("message.konosuba.chant")
                    .withStyle(ChatFormatting.DARK_RED), true);
        }
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel sl)) return;
        int charged = getUseDuration(stack) - remaining;
        double progress = Math.min(1.0D, charged / (double) CHANT_TICKS);
        double radius = 0.8D + 1.6D * progress;
        for (int i = 0; i < 4; i++) {
            double a = charged * 0.35D + i * (Math.PI / 2.0D);
            double x = entity.getX() + Math.cos(a) * radius;
            double z = entity.getZ() + Math.sin(a) * radius;
            sl.sendParticles(ParticleTypes.FLAME, x, entity.getY() + 0.1D, z, 1, 0, 0.02D, 0, 0.0D);
            sl.sendParticles(ParticleTypes.ENCHANT, x, entity.getY() + 1.0D + progress, z, 1, 0.1D, 0.3D, 0.1D, 0.0D);
        }
        if (charged == CHANT_TICKS) {
            sl.playSound(null, entity.blockPosition(), SoundEvents.BEACON_POWER_SELECT,
                    SoundSource.PLAYERS, 1.0F, 1.5F);
        }
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player player)) return;
        int charged = getUseDuration(stack) - timeLeft;
        if (charged < CHANT_TICKS) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.konosuba.interrupted")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (level.isClientSide) return;

        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
        BlockHitResult hit = level.clip(new ClipContext(eye, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 target = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();

        Level.ExplosionInteraction mode = KonosubaConfig.BREAK_BLOCKS.get()
                ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
        level.explode(player, target.x, target.y, target.z,
                KonosubaConfig.EXPLOSION_POWER.get().floatValue(), mode);

        player.displayClientMessage(Component.translatable("message.konosuba.explosion")
                .withStyle(ChatFormatting.RED, ChatFormatting.BOLD), false);

        if (!player.getAbilities().instabuild) {
            int collapse = KonosubaConfig.COLLAPSE_SECONDS.get() * 20;
            if (collapse > 0) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, collapse, 6));
                player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, collapse, 1));
            }
            player.getCooldowns().addCooldown(this, KonosubaConfig.COOLDOWN_SECONDS.get() * 20);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(p.getUsedItemHand()));
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.konosuba.explosion_staff.1").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.konosuba.explosion_staff.2").withStyle(ChatFormatting.DARK_RED));
    }
}
