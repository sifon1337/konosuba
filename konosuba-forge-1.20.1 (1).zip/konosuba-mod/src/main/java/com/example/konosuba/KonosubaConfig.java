package com.example.konosuba;

import net.minecraftforge.common.ForgeConfigSpec;

public class KonosubaConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue EXPLOSION_POWER;
    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS;
    public static final ForgeConfigSpec.IntValue COLLAPSE_SECONDS;
    public static final ForgeConfigSpec.BooleanValue BREAK_BLOCKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("explosion_staff");
        EXPLOSION_POWER = b.comment("Explosion power (TNT = 4.0)")
                .defineInRange("power", 8.0D, 1.0D, 30.0D);
        COOLDOWN_SECONDS = b.comment("Cooldown between casts, in seconds")
                .defineInRange("cooldown_seconds", 30, 1, 3600);
        COLLAPSE_SECONDS = b.comment("How long the caster is paralysed after casting (Megumin style)")
                .defineInRange("collapse_seconds", 10, 0, 300);
        BREAK_BLOCKS = b.comment("Whether the staff's explosion destroys blocks")
                .define("break_blocks", true);
        b.pop();
        SPEC = b.build();
    }
}
