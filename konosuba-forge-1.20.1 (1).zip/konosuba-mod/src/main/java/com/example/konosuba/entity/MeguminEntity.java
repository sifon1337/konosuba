package com.example.konosuba.entity;

import com.example.konosuba.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Archwizard: casts Explosion at monsters from far away, then collapses for a while. */
public class MeguminEntity extends KonosubaCharacter {
    public static final int COOLDOWN_TICKS = 2400;   // 2 minutes
    public static final int COLLAPSE_TICKS = 400;

    private long nextCastTime = 0L;

    public MeguminEntity(EntityType<? extends MeguminEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return baseAttributes().add(Attributes.MAX_HEALTH, 16.0D);
    }

    @Override
    protected String getCharacterId() {
        return "megumin";
    }

    @Override
    protected MobEffectInstance getBlessing() {
        return new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 1200, 0);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(1, new MeguminExplosionGoal(this));
        this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, Monster.class, 7.0F, 1.0D, 1.3D));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.EXPLOSION_STAFF.get()));
        this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    public boolean canCast() {
        return this.level().getGameTime() >= nextCastTime;
    }

    public void announceChant() {
        for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(32.0D))) {
            p.displayClientMessage(Component.translatable("message.konosuba.megumin.chant"), true);
        }
    }

    public void castExplosion(Vec3 pos) {
        this.level().explode(this, pos.x, pos.y, pos.z, 4.0F, Level.ExplosionInteraction.MOB);
        this.nextCastTime = this.level().getGameTime() + COOLDOWN_TICKS;
        this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, COLLAPSE_TICKS, 6, false, false));
        this.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, COLLAPSE_TICKS, 1, false, false));
        for (Player p : this.level().getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(48.0D))) {
            p.displayClientMessage(Component.translatable("message.konosuba.megumin.explosion"), false);
        }
        this.setTarget(null);
    }
}
