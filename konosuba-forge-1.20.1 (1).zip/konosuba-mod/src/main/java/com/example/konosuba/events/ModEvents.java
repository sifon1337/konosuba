package com.example.konosuba.events;

import com.example.konosuba.KonosubaMod;
import com.example.konosuba.entity.AquaEntity;
import com.example.konosuba.entity.DarknessEntity;
import com.example.konosuba.entity.KazumaEntity;
import com.example.konosuba.entity.KonosubaCharacter;
import com.example.konosuba.entity.MeguminEntity;
import com.example.konosuba.registry.ModEntities;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KonosubaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.AQUA.get(), AquaEntity.createAttributes().build());
        event.put(ModEntities.MEGUMIN.get(), MeguminEntity.createAttributes().build());
        event.put(ModEntities.KAZUMA.get(), KazumaEntity.createAttributes().build());
        event.put(ModEntities.DARKNESS.get(), DarknessEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        place(event, ModEntities.AQUA.get());
        place(event, ModEntities.MEGUMIN.get());
        place(event, ModEntities.KAZUMA.get());
        place(event, ModEntities.DARKNESS.get());
    }

    private static <T extends KonosubaCharacter> void place(SpawnPlacementRegisterEvent event, EntityType<T> type) {
        event.register(type, SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Mob::checkMobSpawnRules, SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
}
