package com.example.konosuba.registry;

import com.example.konosuba.KonosubaMod;
import com.example.konosuba.item.AleItem;
import com.example.konosuba.item.ExplosionStaffItem;
import com.example.konosuba.item.KazumaSwordItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, KonosubaMod.MODID);

    public static final RegistryObject<Item> EXPLOSION_STAFF = ITEMS.register("explosion_staff",
            () -> new ExplosionStaffItem(new Item.Properties().durability(64).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> KAZUMA_SWORD = ITEMS.register("kazuma_sword",
            () -> new KazumaSwordItem(new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> ALE = ITEMS.register("ale",
            () -> new AleItem(new Item.Properties().stacksTo(16).food(
                    new FoodProperties.Builder()
                            .nutrition(3).saturationMod(0.4F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 600, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 200, 0), 0.5F)
                            .build())));

    public static final RegistryObject<Item> ERIS_COIN = ITEMS.register("eris_coin",
            () -> new Item(new Item.Properties()) {
                @Override
                public void appendHoverText(net.minecraft.world.item.ItemStack stack,
                                            net.minecraft.world.level.Level level,
                                            java.util.List<net.minecraft.network.chat.Component> tooltip,
                                            net.minecraft.world.item.TooltipFlag flag) {
                    tooltip.add(net.minecraft.network.chat.Component.translatable("tooltip.konosuba.eris_coin.1")
                            .withStyle(net.minecraft.ChatFormatting.GRAY));
                }
            });

    public static final RegistryObject<Item> AQUA_SPAWN_EGG = ITEMS.register("aqua_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.AQUA, 0x6EC6E8, 0x3A75C4, new Item.Properties()));
    public static final RegistryObject<Item> MEGUMIN_SPAWN_EGG = ITEMS.register("megumin_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MEGUMIN, 0x1D1D1D, 0xD02020, new Item.Properties()));
    public static final RegistryObject<Item> KAZUMA_SPAWN_EGG = ITEMS.register("kazuma_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.KAZUMA, 0x6B4A2B, 0x3F7A3A, new Item.Properties()));
    public static final RegistryObject<Item> DARKNESS_SPAWN_EGG = ITEMS.register("darkness_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.DARKNESS, 0xE6C86A, 0xB8BCC4, new Item.Properties()));
}
