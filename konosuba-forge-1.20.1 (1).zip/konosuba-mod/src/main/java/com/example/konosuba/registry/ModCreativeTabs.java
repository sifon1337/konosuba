package com.example.konosuba.registry;

import com.example.konosuba.KonosubaMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KonosubaMod.MODID);

    public static final RegistryObject<CreativeModeTab> KONOSUBA_TAB = TABS.register("konosuba",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.konosuba"))
                    .icon(() -> new ItemStack(ModItems.EXPLOSION_STAFF.get()))
                    .displayItems((params, output) ->
                            ModItems.ITEMS.getEntries().forEach(e -> output.accept(e.get())))
                    .build());
}
