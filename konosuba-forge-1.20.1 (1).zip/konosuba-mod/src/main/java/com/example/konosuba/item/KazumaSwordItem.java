package com.example.konosuba.item;

import com.example.konosuba.registry.ModItems;
import com.example.konosuba.registry.ModTiers;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;

import java.util.List;

/** A sword with Kazuma's "Steal" skill. */
public class KazumaSwordItem extends SwordItem {
    public KazumaSwordItem(Properties properties) {
        super(ModTiers.KAZUMA, 3, -2.4F, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (!attacker.level().isClientSide && attacker.getRandom().nextFloat() < 0.15F) {
            ItemStack loot;
            ItemStack held = target.getMainHandItem();
            if (!held.isEmpty()) {
                loot = held.copy();
                target.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
            } else {
                loot = new ItemStack(ModItems.ERIS_COIN.get(), 1 + attacker.getRandom().nextInt(3));
            }
            if (attacker instanceof Player player) {
                if (!player.getInventory().add(loot)) player.drop(loot, false);
                player.displayClientMessage(Component.translatable("message.konosuba.steal")
                        .withStyle(ChatFormatting.GREEN), true);
            } else {
                target.spawnAtLocation(loot);
            }
            if (attacker.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, target.getX(), target.getY() + 1.0D,
                        target.getZ(), 8, 0.3D, 0.4D, 0.3D, 0.0D);
            }
        }
        return result;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.konosuba.kazuma_sword.1").withStyle(ChatFormatting.GREEN));
    }
}
