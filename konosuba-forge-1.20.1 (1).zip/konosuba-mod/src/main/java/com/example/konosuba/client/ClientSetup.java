package com.example.konosuba.client;

import com.example.konosuba.KonosubaMod;
import com.example.konosuba.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KonosubaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.AQUA.get(), ctx -> new CharacterRenderer<>(ctx, "aqua"));
        event.registerEntityRenderer(ModEntities.MEGUMIN.get(), ctx -> new CharacterRenderer<>(ctx, "megumin"));
        event.registerEntityRenderer(ModEntities.KAZUMA.get(), ctx -> new CharacterRenderer<>(ctx, "kazuma"));
        event.registerEntityRenderer(ModEntities.DARKNESS.get(), ctx -> new CharacterRenderer<>(ctx, "darkness"));
    }
}
